config = {
  "path" : "gallery"
}