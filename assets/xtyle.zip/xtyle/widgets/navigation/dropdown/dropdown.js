/*! xchema | xtyle
 *  created: Jan 2, 2013
 *  by: Mariz Melo
 *  desc: Dropdown widget JavaScript file
 */

// dropdown horizontal
// dropdown vertical

(function($){
  $.fn.widget-menus-dropdown = function(){ 
    var $config = {
      selectors : {
        "width",
        "height",
        "background" : {
          ""
        }
      }
    }
  }//fn.dropbox
  
})(jQuery);